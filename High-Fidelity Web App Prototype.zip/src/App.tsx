import { useState, useRef, useCallback } from "react";

type Page = "landing" | "converter";
type Format = "CSV" | "XLSX" | "SQLite";
type ConversionState = "idle" | "loading" | "success" | "error";

function detectFormat(filename: string): Format | null {
  const ext = filename.split(".").pop()?.toLowerCase();
  if (ext === "csv") return "CSV";
  if (ext === "xlsx" || ext === "xls") return "XLSX";
  if (ext === "sqlite" || ext === "db" || ext === "sqlite3") return "SQLite";
  return null;
}

function FormatBadge({ label }: { label: string }) {
  return (
    <span
      className="inline-flex items-center px-3 py-1 text-xs font-mono font-medium tracking-widest uppercase border"
      style={{
        borderColor: "var(--border)",
        color: "var(--muted-foreground)",
        background: "var(--card)",
        fontFamily: "'DM Mono', monospace",
        letterSpacing: "0.08em",
      }}
    >
      {label}
    </span>
  );
}

function LandingPage({ onStart }: { onStart: () => void }) {
  return (
    <div className="min-h-screen flex flex-col" style={{ background: "var(--background)" }}>
      {/* Header */}
      <header
        className="flex items-center justify-between px-8 py-5 border-b"
        style={{ borderColor: "var(--border)" }}
      >
        <div className="flex items-center gap-2.5">
          <div
            className="w-6 h-6 flex items-center justify-center"
            style={{ background: "var(--primary)" }}
          >
            <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
              <rect x="1" y="1" width="5" height="5" fill="white" />
              <rect x="8" y="1" width="5" height="5" fill="white" opacity="0.6" />
              <rect x="1" y="8" width="5" height="5" fill="white" opacity="0.6" />
              <rect x="8" y="8" width="5" height="5" fill="white" />
            </svg>
          </div>
          <span className="text-sm font-semibold tracking-tight" style={{ color: "var(--foreground)" }}>
            DataStr
          </span>
        </div>
        <button
          onClick={onStart}
          className="text-sm font-medium px-4 py-2 transition-colors"
          style={{ color: "var(--muted-foreground)" }}
          onMouseEnter={(e) => (e.currentTarget.style.color = "var(--foreground)")}
          onMouseLeave={(e) => (e.currentTarget.style.color = "var(--muted-foreground)")}
        >
          Converter
        </button>
      </header>

      {/* Hero */}
      <main className="flex-1 flex flex-col justify-center px-8 max-w-3xl mx-auto w-full py-24">
        <div
          className="text-xs font-mono font-medium uppercase tracking-widest mb-8"
          style={{ color: "var(--primary)", fontFamily: "'DM Mono', monospace", letterSpacing: "0.1em" }}
        >
          Conversão de arquivos
        </div>

        <h1
          className="text-5xl font-light leading-tight mb-6"
          style={{ color: "var(--foreground)", letterSpacing: "-0.02em", lineHeight: 1.1 }}
        >
          Converta seus arquivos
          <br />
          <span className="font-semibold">de forma simples</span>
          <br />e rápida.
        </h1>

        <p
          className="text-base font-light max-w-md mb-12 leading-relaxed"
          style={{ color: "var(--muted-foreground)" }}
        >
          Transforme dados entre CSV, XLSX e SQLite sem instalação, sem conta.
          Faça o upload, escolha o formato e baixe o arquivo convertido.
        </p>

        <div className="flex items-center gap-4">
          <button
            onClick={onStart}
            className="px-6 py-3 text-sm font-medium transition-opacity"
            style={{
              background: "var(--primary)",
              color: "var(--primary-foreground)",
            }}
            onMouseEnter={(e) => (e.currentTarget.style.opacity = "0.88")}
            onMouseLeave={(e) => (e.currentTarget.style.opacity = "1")}
          >
            Começar conversão
          </button>
        </div>

        {/* Formats */}
        <div
          className="mt-16 pt-10 border-t flex flex-col gap-4"
          style={{ borderColor: "var(--border)" }}
        >
          <span className="text-xs font-mono uppercase tracking-widest" style={{ color: "var(--muted-foreground)", fontFamily: "'DM Mono', monospace" }}>
            Formatos suportados
          </span>
          <div className="flex gap-3">
            <FormatBadge label="CSV" />
            <FormatBadge label="XLSX" />
            <FormatBadge label="SQLite" />
          </div>
          <p className="text-xs max-w-sm leading-relaxed" style={{ color: "var(--muted-foreground)" }}>
            Suporte a arquivos .csv, .xlsx, .xls, .sqlite, .db e .sqlite3.
            Conversões bidirecionais entre todos os formatos.
          </p>
        </div>
      </main>

      {/* Footer */}
      <footer
        className="px-8 py-5 border-t flex items-center justify-between"
        style={{ borderColor: "var(--border)" }}
      >
        <span className="text-xs" style={{ color: "var(--muted-foreground)", fontFamily: "'DM Mono', monospace" }}>
          DataStr
        </span>
        <span className="text-xs" style={{ color: "var(--muted-foreground)" }}>
          Nenhum dado é armazenado.
        </span>
      </footer>
    </div>
  );
}

function ConverterPage({ onBack }: { onBack: () => void }) {
  const [file, setFile] = useState<File | null>(null);
  const [inputFormat, setInputFormat] = useState<Format | null>(null);
  const [outputFormat, setOutputFormat] = useState<Format>("CSV");
  const [conversionState, setConversionState] = useState<ConversionState>("idle");
  const [isDragging, setIsDragging] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFile = useCallback((f: File) => {
    setFile(f);
    setConversionState("idle");
    const detected = detectFormat(f.name);
    setInputFormat(detected);
    if (detected) {
      const others: Format[] = (["CSV", "XLSX", "SQLite"] as Format[]).filter((x) => x !== detected);
      setOutputFormat(others[0]);
    }
  }, []);

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const f = e.dataTransfer.files[0];
    if (f) handleFile(f);
  };

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    if (f) handleFile(f);
  };

  const handleConvert = () => {
    if (!file) return;
    setConversionState("loading");
    setTimeout(() => {
      setConversionState("success");
    }, 1800);
  };

  const handleReset = () => {
    setFile(null);
    setInputFormat(null);
    setOutputFormat("CSV");
    setConversionState("idle");
    if (fileInputRef.current) fileInputRef.current.value = "";
  };

  const formats: Format[] = ["CSV", "XLSX", "SQLite"];

  const formatExt: Record<Format, string> = {
    CSV: "csv",
    XLSX: "xlsx",
    SQLite: "sqlite",
  };

  return (
    <div className="min-h-screen flex flex-col" style={{ background: "var(--background)" }}>
      {/* Header */}
      <header
        className="flex items-center justify-between px-8 py-5 border-b"
        style={{ borderColor: "var(--border)" }}
      >
        <button
          onClick={onBack}
          className="flex items-center gap-2.5 group"
        >
          <div
            className="w-6 h-6 flex items-center justify-center"
            style={{ background: "var(--primary)" }}
          >
            <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
              <rect x="1" y="1" width="5" height="5" fill="white" />
              <rect x="8" y="1" width="5" height="5" fill="white" opacity="0.6" />
              <rect x="1" y="8" width="5" height="5" fill="white" opacity="0.6" />
              <rect x="8" y="8" width="5" height="5" fill="white" />
            </svg>
          </div>
          <span className="text-sm font-semibold tracking-tight" style={{ color: "var(--foreground)" }}>
            DataStr
          </span>
        </button>
        <span
          className="text-xs font-mono uppercase tracking-widest"
          style={{ color: "var(--muted-foreground)", fontFamily: "'DM Mono', monospace" }}
        >
          Converter
        </span>
      </header>

      {/* Main */}
      <main className="flex-1 px-8 py-14 max-w-2xl mx-auto w-full">
        <h1
          className="text-2xl font-semibold mb-1"
          style={{ color: "var(--foreground)", letterSpacing: "-0.015em" }}
        >
          Converter arquivo
        </h1>
        <p className="text-sm mb-10" style={{ color: "var(--muted-foreground)" }}>
          Faça o upload de um arquivo e escolha o formato de saída.
        </p>

        {/* Drop zone */}
        <div
          className="relative border-2 border-dashed transition-colors cursor-pointer mb-6"
          style={{
            borderColor: isDragging ? "var(--primary)" : file ? "var(--border)" : "var(--border)",
            background: isDragging ? "rgba(43,92,230,0.03)" : file ? "var(--card)" : "var(--card)",
            minHeight: 180,
          }}
          onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
          onDragLeave={() => setIsDragging(false)}
          onDrop={handleDrop}
          onClick={() => !file && fileInputRef.current?.click()}
        >
          <input
            ref={fileInputRef}
            type="file"
            accept=".csv,.xlsx,.xls,.sqlite,.db,.sqlite3"
            className="hidden"
            onChange={handleFileInput}
          />

          {!file ? (
            <div className="flex flex-col items-center justify-center h-full py-12 gap-3">
              <div
                className="w-10 h-10 flex items-center justify-center border"
                style={{ borderColor: "var(--border)", background: "var(--secondary)" }}
              >
                <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
                  <path d="M9 12V3M9 3L5.5 6.5M9 3L12.5 6.5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="square" style={{ color: "var(--muted-foreground)" }} />
                  <path d="M2 13V15.5H16V13" stroke="currentColor" strokeWidth="1.5" strokeLinecap="square" style={{ color: "var(--muted-foreground)" }} />
                </svg>
              </div>
              <div className="text-center">
                <p className="text-sm font-medium" style={{ color: "var(--foreground)" }}>
                  Arraste um arquivo aqui
                </p>
                <p className="text-xs mt-1" style={{ color: "var(--muted-foreground)" }}>
                  CSV, XLSX ou SQLite
                </p>
              </div>
              <button
                className="mt-2 px-4 py-2 text-xs font-medium border transition-colors"
                style={{
                  borderColor: "var(--border)",
                  color: "var(--foreground)",
                  background: "var(--secondary)",
                }}
                onMouseEnter={(e) => (e.currentTarget.style.background = "var(--border)")}
                onMouseLeave={(e) => (e.currentTarget.style.background = "var(--secondary)")}
                onClick={(e) => { e.stopPropagation(); fileInputRef.current?.click(); }}
              >
                Selecionar arquivo
              </button>
            </div>
          ) : (
            <div className="flex items-center justify-between px-5 py-5">
              <div className="flex items-center gap-4">
                <div
                  className="w-10 h-10 flex items-center justify-center"
                  style={{ background: "var(--primary)" }}
                >
                  <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                    <rect x="2" y="1" width="9" height="14" rx="0" fill="white" opacity="0.15" />
                    <path d="M2 1h7l3 3v11H2V1z" stroke="white" strokeWidth="1.2" strokeLinejoin="miter" />
                    <path d="M9 1v3h3" stroke="white" strokeWidth="1.2" strokeLinejoin="miter" />
                    <path d="M5 8h6M5 10.5h4" stroke="white" strokeWidth="1" strokeLinecap="square" />
                  </svg>
                </div>
                <div>
                  <p className="text-sm font-medium" style={{ color: "var(--foreground)" }}>
                    {file.name}
                  </p>
                  <p
                    className="text-xs mt-0.5 font-mono"
                    style={{ color: "var(--muted-foreground)", fontFamily: "'DM Mono', monospace" }}
                  >
                    {(file.size / 1024).toFixed(1)} KB
                    {inputFormat && (
                      <span
                        className="ml-2 px-1.5 py-0.5 uppercase"
                        style={{ background: "var(--secondary)", color: "var(--primary)", fontSize: 10, letterSpacing: "0.06em" }}
                      >
                        {inputFormat}
                      </span>
                    )}
                  </p>
                </div>
              </div>
              <button
                onClick={(e) => { e.stopPropagation(); handleReset(); }}
                className="text-xs transition-colors"
                style={{ color: "var(--muted-foreground)" }}
                onMouseEnter={(e) => (e.currentTarget.style.color = "var(--foreground)")}
                onMouseLeave={(e) => (e.currentTarget.style.color = "var(--muted-foreground)")}
              >
                Remover
              </button>
            </div>
          )}
        </div>

        {/* Format fields */}
        <div className="grid grid-cols-2 gap-4 mb-8">
          <div>
            <label className="block text-xs font-mono uppercase tracking-widest mb-2" style={{ color: "var(--muted-foreground)", fontFamily: "'DM Mono', monospace" }}>
              Formato de entrada
            </label>
            <div
              className="w-full px-3 py-2.5 text-sm border flex items-center justify-between"
              style={{
                borderColor: "var(--border)",
                background: "var(--secondary)",
                color: inputFormat ? "var(--foreground)" : "var(--muted-foreground)",
              }}
            >
              <span>{inputFormat ?? "Detectado automaticamente"}</span>
              {inputFormat && (
                <svg width="12" height="12" viewBox="0 0 12 12" fill="none" style={{ color: "var(--primary)" }}>
                  <path d="M2 6.5L5 9.5L10 3" stroke="currentColor" strokeWidth="1.5" strokeLinecap="square" />
                </svg>
              )}
            </div>
          </div>

          <div>
            <label className="block text-xs font-mono uppercase tracking-widest mb-2" style={{ color: "var(--muted-foreground)", fontFamily: "'DM Mono', monospace" }}>
              Formato de saída
            </label>
            <div className="relative">
              <select
                value={outputFormat}
                onChange={(e) => setOutputFormat(e.target.value as Format)}
                className="w-full px-3 py-2.5 text-sm border appearance-none cursor-pointer"
                style={{
                  borderColor: "var(--border)",
                  background: "var(--card)",
                  color: "var(--foreground)",
                  outline: "none",
                }}
                disabled={conversionState === "loading" || conversionState === "success"}
              >
                {formats
                  .filter((f) => f !== inputFormat)
                  .map((f) => (
                    <option key={f} value={f}>{f}</option>
                  ))}
                {!inputFormat && formats.map((f) => (
                  <option key={f} value={f}>{f}</option>
                ))}
              </select>
              <div className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" style={{ color: "var(--muted-foreground)" }}>
                <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
                  <path d="M2.5 4.5L6 8L9.5 4.5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="square" />
                </svg>
              </div>
            </div>
          </div>
        </div>

        {/* Convert button */}
        {conversionState !== "success" && (
          <button
            onClick={handleConvert}
            disabled={!file || conversionState === "loading"}
            className="w-full py-3 text-sm font-medium transition-opacity flex items-center justify-center gap-2.5"
            style={{
              background: !file ? "var(--secondary)" : "var(--primary)",
              color: !file ? "var(--muted-foreground)" : "var(--primary-foreground)",
              cursor: !file ? "not-allowed" : "pointer",
            }}
            onMouseEnter={(e) => { if (file && conversionState !== "loading") e.currentTarget.style.opacity = "0.88"; }}
            onMouseLeave={(e) => (e.currentTarget.style.opacity = "1")}
          >
            {conversionState === "loading" ? (
              <>
                <svg className="animate-spin" width="14" height="14" viewBox="0 0 14 14" fill="none">
                  <circle cx="7" cy="7" r="5.5" stroke="currentColor" strokeWidth="1.5" strokeDasharray="20 14" strokeLinecap="round" />
                </svg>
                Convertendo…
              </>
            ) : (
              "Converter arquivo"
            )}
          </button>
        )}

        {/* Feedback states */}
        {conversionState === "error" && (
          <div
            className="mt-4 px-4 py-3 flex items-center gap-3 border text-sm"
            style={{ borderColor: "#f87171", background: "#fff5f5", color: "#b91c1c" }}
          >
            <svg width="14" height="14" viewBox="0 0 14 14" fill="none" style={{ flexShrink: 0 }}>
              <circle cx="7" cy="7" r="6" stroke="#b91c1c" strokeWidth="1.4" />
              <path d="M7 4v4" stroke="#b91c1c" strokeWidth="1.4" strokeLinecap="square" />
              <circle cx="7" cy="10" r="0.8" fill="#b91c1c" />
            </svg>
            Não foi possível converter o arquivo. Verifique o formato e tente novamente.
          </div>
        )}

        {conversionState === "success" && (
          <div className="border" style={{ borderColor: "var(--border)", background: "var(--card)" }}>
            <div
              className="px-5 py-4 border-b flex items-center gap-3"
              style={{ borderColor: "var(--border)" }}
            >
              <div
                className="w-8 h-8 flex items-center justify-center"
                style={{ background: "#ecfdf5" }}
              >
                <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
                  <path d="M2 7.5L5.5 11L12 4" stroke="#16a34a" strokeWidth="1.8" strokeLinecap="square" />
                </svg>
              </div>
              <div>
                <p className="text-sm font-medium" style={{ color: "var(--foreground)" }}>
                  Conversão concluída
                </p>
                <p className="text-xs mt-0.5 font-mono" style={{ color: "var(--muted-foreground)", fontFamily: "'DM Mono', monospace" }}>
                  {file?.name.replace(/\.[^.]+$/, "")}.{formatExt[outputFormat]} · {outputFormat}
                </p>
              </div>
            </div>
            <div className="px-5 py-4 flex gap-3">
              <button
                className="flex-1 py-2.5 text-sm font-medium transition-opacity flex items-center justify-center gap-2"
                style={{ background: "var(--primary)", color: "var(--primary-foreground)" }}
                onMouseEnter={(e) => (e.currentTarget.style.opacity = "0.88")}
                onMouseLeave={(e) => (e.currentTarget.style.opacity = "1")}
              >
                <svg width="13" height="13" viewBox="0 0 13 13" fill="none">
                  <path d="M6.5 1v8M6.5 9L3 6M6.5 9L10 6" stroke="currentColor" strokeWidth="1.5" strokeLinecap="square" />
                  <path d="M1.5 10.5h10" stroke="currentColor" strokeWidth="1.5" strokeLinecap="square" />
                </svg>
                Baixar arquivo
              </button>
              <button
                onClick={handleReset}
                className="px-4 py-2.5 text-sm border transition-colors"
                style={{ borderColor: "var(--border)", color: "var(--foreground)", background: "var(--secondary)" }}
                onMouseEnter={(e) => (e.currentTarget.style.background = "var(--border)")}
                onMouseLeave={(e) => (e.currentTarget.style.background = "var(--secondary)")}
              >
                Nova conversão
              </button>
            </div>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer
        className="px-8 py-5 border-t"
        style={{ borderColor: "var(--border)" }}
      >
        <span className="text-xs" style={{ color: "var(--muted-foreground)" }}>
          Nenhum dado é armazenado nos nossos servidores.
        </span>
      </footer>
    </div>
  );
}

export default function App() {
  const [page, setPage] = useState<Page>("landing");

  return page === "landing" ? (
    <LandingPage onStart={() => setPage("converter")} />
  ) : (
    <ConverterPage onBack={() => setPage("landing")} />
  );
}
